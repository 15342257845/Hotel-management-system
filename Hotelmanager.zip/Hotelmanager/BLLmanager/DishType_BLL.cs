﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class DishType_BLL
    {
        public static DataTable sel()
        {
           return   DALmanager.DishType_DAL.sel();
        }
        public static DataTable jzsel()
        {
            return DALmanager.DishType_DAL.jzsel();
        }
        public static bool update(MODEL.DishType dyp)
        {
            return DALmanager.DishType_DAL.update(dyp);
        }
        public static bool del(MODEL.DishType dyp)
        {
            return DALmanager.DishType_DAL.del(dyp);
        }
        public static bool tianjia(MODEL.DishType dyp)
        {
            return DALmanager.DishType_DAL.tianjia(dyp);
        }

        public static DataTable selcaip(MODEL.DishType dyp)
        {

            return DALmanager.DishType_DAL.selcaip(dyp);
        }
    }
}
