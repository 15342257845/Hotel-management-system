﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class Dish_BLL
    {
        public static DataTable sel()
        {
           return DALmanager.Dish_DAL.sel();
        }
        
        public static DataTable txtchansel(MODEL.Dish ds, MODEL.DishType dtp)
        {
            return DALmanager.Dish_DAL.txtchansel(ds,dtp);
        }
       
        public static bool insert(MODEL.Dish ds)
        {
            return DALmanager.Dish_DAL.insert(ds);
        }
        public static bool update(MODEL.Dish ds)
        {
            return DALmanager.Dish_DAL.update(ds);
        }
        public static bool del(MODEL.Dish ds)
        {
            return DALmanager.Dish_DAL.del(ds);
        }
    }
}
