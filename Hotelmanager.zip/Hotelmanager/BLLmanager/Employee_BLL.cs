﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class Employee_BLL
    {
        public static DataTable Loginsel(MODEL.Employee emp)
        {
            return DALmanager.Employee_DAL.Loginsel(emp);
        }
        public static DataTable yaungongsel()
        {
            return DALmanager.Employee_DAL.yuangongsel();
        }
        public static bool tianjia(MODEL.Employee emp)
        {
            return DALmanager.Employee_DAL.tianjia(emp);
        }
        public static bool shanchu(MODEL.Employee emp)
        {
            return DALmanager.Employee_DAL.shanchu(emp);
        }
        public static bool xiugai(MODEL.Employee emp)
        {
            return DALmanager.Employee_DAL.xiugai(emp);
        }
    }
}
