﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class HallTable_BLL
    {
        public static DataTable sel()
        {
            return DALmanager.HallTable_DAL.sel();
        }

        public static DataTable likesel(MODEL.HallTable htl)
        {
            return DALmanager.HallTable_DAL.likesel(htl);
        }

        //   public static bool tianjia(MODEL.MemberType mt)
        //{
        //    return DALmanager.MTypeId_DAL.tianjia(mt);
        //}
        //public static bool shanchu(MODEL.MemberType mt)
        //{
        //    return DALmanager.MTypeId_DAL.shanchu(mt);
        //}
        //public static bool xiugai(MODEL.MemberType mt)
        //{
        //    return DALmanager.MTypeId_DAL.xiugai(mt);
        //}

        public static bool insert(MODEL.HallTable htl)
        {
            return DALmanager.HallTable_DAL.insert(htl);
        }
        public static bool update(MODEL.HallTable htl)
        {

            return DALmanager.HallTable_DAL.update(htl);
        }
        public static bool del(MODEL.HallTable htl)
        {
            return DALmanager.HallTable_DAL.del(htl);
        }
        public static bool insertqqq()
        {
            return DALmanager.HallTable_DAL.insertqqq();
        }
    }
}
