﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
   public class Hall_BLL
    {
        public static DataTable sel()
        {
            return DALmanager.Hall_DAL.sel();
        }
        public static DataTable jzsel()
        {
            return DALmanager.Hall_DAL.jzsel();
        }
        public static DataTable insertsel(MODEL.Hall hl)
        {
           
            return DALmanager.Hall_DAL.insertsel(hl);
        }
        public static DataTable seljz()
        {
            return DALmanager.Hall_DAL.seljz();
        }
        public static bool insert(MODEL.Hall hl)
        {
            return DALmanager.Hall_DAL.insert(hl);
        }
        public static bool update(MODEL.Hall hl)
        {
            return DALmanager.Hall_DAL.update(hl);
        }
        public static bool del(MODEL.Hall hl)
        {
            return DALmanager.Hall_DAL.del(hl);
        }
    }
}
