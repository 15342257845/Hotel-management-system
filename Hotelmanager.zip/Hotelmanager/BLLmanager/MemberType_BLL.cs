﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class MemberType_BLL
    {
        public static DataTable sel()
        {
           return DALmanager.MTypeId_DAL.sel();
        }
        public static DataTable jzsel()
        {
            return DALmanager.MTypeId_DAL.jzsel();
        }

        public static bool tianjia(MODEL.MemberType mt)
        {
            return DALmanager.MTypeId_DAL.tianjia(mt);
        }
        public static bool shanchu(MODEL.MemberType mt)
        {
            return DALmanager.MTypeId_DAL.shanchu(mt);
        }
        public static bool xiugai(MODEL.MemberType mt)
        {
            return DALmanager.MTypeId_DAL.xiugai(mt);
        }
    }
}
