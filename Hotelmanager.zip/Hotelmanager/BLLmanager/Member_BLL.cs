﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class Member_BLL
    {
        public static DataTable sel(MODEL.Member mbr)
        {
            return DALmanager.Member_DAL.sel(mbr);
        }

        
        public static DataTable txtchansel(MODEL.Member mbr)
        {
            return DALmanager.Member_DAL.txtchansel(mbr);
        }
        public static bool insert(MODEL.Member mbr)
        {
            return DALmanager.Member_DAL.insert(mbr);
        }

        public static bool del(MODEL.Member mbr)
        {
            return DALmanager.Member_DAL.del(mbr);
        }
        public static bool update(MODEL.Member mbr)
        {
            return DALmanager.Member_DAL.update(mbr);
        }

        public static DataTable selsel(MODEL.MemberType mbtr)
        {
            return DALmanager.Member_DAL.selsel(mbtr);
        }
    }
}
