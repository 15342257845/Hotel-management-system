﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace BLLmanager
{
   public class Order_BLL
    {
        public static DataTable tingsel()
        {

            return DALmanager.Orde_DAL.tingsel();
        }
        public static DataTable zhuosel(int HID)
        {

            return DALmanager.Orde_DAL.zhuosel(HID);
        }
        public static DataTable seldish()
        {

            return DALmanager.Orde_DAL.seldish();
        }
        public static DataTable zhuoID(MODEL.HallTable htl)
        {
            return DALmanager.Orde_DAL.zhuoID(htl);
        }
        public static bool insertID(MODEL.OrderDetail odl)
        {
            return DALmanager.Orde_DAL.insertID(odl);
        }

        public static DataTable selOID(MODEL.Order or)
        {

            return DALmanager.Orde_DAL.selOID(or);
        }

        public static DataTable selfill(MODEL.OrderDetail odl)
        {

            return DALmanager.Orde_DAL.selfill(odl);
        }

        public static bool del(MODEL.OrderDetail odl)
        {

            return DALmanager.Orde_DAL.del(odl);
        }

        public static bool update(MODEL.OrderDetail odl)
        {

            return DALmanager.Orde_DAL.update(odl);
        }
    }
}
