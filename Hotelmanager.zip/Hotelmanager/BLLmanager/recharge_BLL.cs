﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLLmanager
{
    public class recharge_BLL
    {
        public static DataTable sel(int ID)
        {
            return DALmanager.recharge_DAL.sel(ID);
        }

        public static bool chongzhi(int yue,int ID)
        {
            return DALmanager.recharge_DAL.chongzhi(yue,ID);
        }
    }
}
