﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;

namespace DALmanager
{
    public class DBHelper
    {
        //使用web.config配置连接字符串
        public static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ToString();
        /// <summary>
        /// 公共的查询方法(SQL语句，可变参数 数组 sp)
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="sp"></param>
        /// <returns></returns>
        public static DataTable comSelect(string sql, params SqlParameter[] sp)
        {   //using在这里的作用是using完了之后自动释放（关闭）链接
            using (SqlConnection conn = new SqlConnection(connStr))
            {//先要给DataSet或者DataTable
                DataTable dt = new DataTable();
                //判断连接对象的状态，如果是关闭的就打开
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                    //适配器.选择命令.参数.添加参数范围，这句话是添加参数的关键，跟增删改的不同
                    sda.SelectCommand.Parameters.AddRange(sp);
                    sda.Fill(dt);
                }
                return dt;
            }

        }
        /// <summary>
        /// 公共的增删改方法(sql语句，可变的参数 数组sp)
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static bool insertUpDel(string sql, params SqlParameter[] sp)
        {

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                SqlCommand cmd = new SqlCommand(sql, conn);
                if (sp != null)//如果参数不等于空
                {//参数添加
                    cmd.Parameters.AddRange(sp);
                }
                int i = cmd.ExecuteNonQuery();//执行无查询，就是增删改
                if (i > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }




        }
    }
}
