﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
   public class DishType_DAL
    {
        public static DataTable sel()
        {
            string sql = "select DTypeId'编号',DTittle'类型' from DishType where DIsdelete=0";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable jzsel()
        {
            string sql = "select DTypeId,DTittle from DishType";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static bool update(MODEL.DishType dyp)
        {
            string sql = "update DishType set DTittle='"+dyp.DTittle+"' where DTypeId="+dyp.DTypeId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool del(MODEL.DishType dyp)
        {
            string sql = "update DishType set DIsdelete=1 where DTypeId="+dyp.DTypeId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static bool tianjia(MODEL.DishType dyp)
        {
            string sql = "insert into DishType(DTittle,DIsdelete) values('" + dyp.DTittle+"',0)";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static DataTable selcaip(MODEL.DishType dyp)
        {
            string sql = "select DTypeId from DishType where DTittle='"+dyp.DTittle+"'";
            return DALmanager.DBHelper.comSelect(sql);
        }

    }
}
