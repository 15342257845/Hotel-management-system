﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
    public class Dish_DAL
    {
        public static DataTable sel()
        {
            string sql = " select DId'编号',Dish.DTittle'菜名',DPrice'价格',DChar'首字母',DishType.DTittle'菜品类别' from Dish inner join DishType on DishType.DTypeId=Dish.DTypeId ";
            return DALmanager.DBHelper.comSelect(sql);
        }

        

        public static DataTable txtchansel(MODEL.Dish ds,MODEL.DishType dtp)
        {
            string sql = " select DId'编号',Dish.DTittle'菜名',DPrice'价格',DChar'首字母',DishType.DTittle'菜品类别' from Dish inner join DishType on DishType.DTypeId = Dish.DTypeId where DishType.DTittle like '%"+dtp.DTittle+"%' and Dish.DTittle like '%"+ds.DTittle+"%'";
           
            return DALmanager.DBHelper.comSelect(sql);
        }
        
        public static bool insert(MODEL.Dish ds)
        {
            string sql = "insert into Dish(DTittle,DPrice,DChar,DTypeId) values('"+ds.DTittle+"',"+ds.DPrice+",'"+ds.DChar+"',"+ds.DTypeId+")";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static bool del(MODEL.Dish ds)
        {
            string sql = "delete  from Dish where DId=" + ds.DId + "";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool update(MODEL.Dish ds)
        {
            string sql = "update Dish set DTittle = '"+ds.DTittle+"', DPrice = "+ds.DPrice+", DChar ='"+ds.DChar+"', DTypeId = "+ds.DTypeId+" where DId = "+ds.DId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
    }
}
