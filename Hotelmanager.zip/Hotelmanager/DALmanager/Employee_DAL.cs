﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DALmanager
{
    public class Employee_DAL
    {
        public static DataTable Loginsel(MODEL.Employee emp)
        {
            string sql = " select EName,EPwd,EType from Employee where EName='"+emp.EName+"' and EPwd='"+emp.EPwd+"'";
            return DBHelper.comSelect(sql);
        }

        public static DataTable yuangongsel()
        {
            //string type = "";
            //if (emp.EType == true)
            //{
            //    type = "经理";
            //}
            //if (emp.EType == false)
            //{
            //    type = "店员";
            //}
            string sql = "select EId'用户编号',EName'用户名',EPwd'密码','员工类型'=case(EType) when 0 then '经理' when 1 then '员工' end from Employee";
            return DBHelper.comSelect(sql);
        }

        public static bool tianjia(MODEL.Employee emp)
        {
            //int i=0;
            //if (emp.EType==true)
            //{
            //    i = 1;
            //}
            //if (emp.EType==false)
            //{
            //    i = 0;
            //}
           
            int i = emp.EType == true ? 0 : 1;
            string sql = "insert into Employee(EName,EPwd,EType) values("+emp.EName+","+emp.EPwd+","+i+")";
            return DBHelper.insertUpDel(sql);
        }

        public static bool shanchu(MODEL.Employee emp)
        {
            string sql = " delete  from Employee where EId="+emp.EId+"";
            return DBHelper.insertUpDel(sql);
        }

        public static bool xiugai(MODEL.Employee emp)
        {
            int etype = emp.EType == true ? 1 : 0;
            string sql = "update Employee set EName="+emp.EName+",EPwd="+emp.EPwd+",EType="+etype+" where EId="+emp.EId+"";
            return DBHelper.insertUpDel(sql);
        }
    }
}
