﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
     public  class HallTable_DAL
    {
        public static DataTable sel()
        {
            string sql = "select TId'编号',TTittle'名称','是否空闲'=case(TIsFree) when 0 then '空闲' when 1 then '非空闲' end,HId'厅包' from HallTable where TIsdelete=0";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable likesel(MODEL.HallTable htl)
        {
            //string sql = @"select TId'编号',TTittle'类型','是否空闲'=case(TIsFree) when 0 then '空闲' when 1 then '非空闲' end,HId'厅包' from HallTable";
            //if (!string.IsNullOrEmpty(htl.HId.ToString()))
            //{
            string sql = "";
            if (htl.HId>-1)
            {
                sql = "select TId'编号',TTittle'名称','是否空闲'=case(TIsFree) when 0 then '空闲' when 1 then '非空闲' end,HId'厅包' from HallTable where HId like '%" + htl.HId + "%' and TIsFree like '%" + htl.TIsFree + "%' and TIsdelete=0";

            }
            else
            {
                 sql = "select TId'编号',TTittle'名称','是否空闲'=case(TIsFree) when 0 then '空闲' when 1 then '非空闲' end,HId'厅包' from HallTable where TIsdelete=0";
            }
            return DALmanager.DBHelper.comSelect(sql);

        }

        public static bool insert(MODEL.HallTable htl)
        {
            string sql = "insert into HallTable(TTittle,HId,TIsFree,TIsdelete) values('"+htl.TTittle+"',"+htl.HId+","+htl.TIsFree+",0)";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static bool update(MODEL.HallTable htl)
        {
            string sql = "update HallTable set TTittle='"+htl.TTittle+"',HId="+htl.HId+",TIsFree="+htl.TIsFree+" where TId="+htl.TId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static bool del(MODEL.HallTable htl)
        {
            string sql = "update HallTable set TIsdelete=1 where TId="+htl.TId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool insertqqq()
        {
            string sql = "insert into [Order](ODate,OMoney,OIsPay,TId,ODiscount) values(GetDate(),666,0,810+1,0.87)";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

    }
}
