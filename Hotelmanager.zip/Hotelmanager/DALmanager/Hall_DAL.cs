﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
   public class Hall_DAL
    {
        public static DataTable sel()
        {
            string sql = "select HId'编号',HTittle'名称' from Hall where HIsdelete=0";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable jzsel()
        {
            string sql = "select HId,HTittle from Hall";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static bool insert(MODEL.Hall hl)
        {
            string sql = "insert into Hall(HTittle, HIsdelete) values('"+hl.HTittle+"', 0)";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static DataTable insertsel(MODEL.Hall hl)
        {
            string sql = "select HId from Hall where HTittle='"+hl.HTittle+"'";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable seljz()
        {
            string sql = "select HId, HTittle from Hall";
            return DALmanager.DBHelper.comSelect(sql);
            
        }

        public static bool del(MODEL.Hall hl)
        {
            string sql = "update Hall set HIsdelete=1 where HId="+hl.HId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool update(MODEL.Hall hl)
        {
            string sql = "update Hall set HTittle='" + hl.HTittle + "' where HId='" + hl.HId + "'"; 
            return DALmanager.DBHelper.insertUpDel(sql);
        }

    }
}
