﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DALmanager
{
    public class MTypeId_DAL
    {
        public static DataTable sel()
        {
            string sql = "select MTypeId'编号',MTittle'会员类型',MDiscount'折扣' from MemberType";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable jzsel()
        {
            string sql = "select MTypeId,MTittle from MemberType";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static bool tianjia(MODEL.MemberType mt)
        {
            string sql = "insert into MemberType(MTittle,MDiscount) values('"+ mt.MTittle + "',"+ mt.MDiscount + ")";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool shanchu(MODEL.MemberType mt)
        {
            string sql = "delete  from MemberType where MTypeId="+mt.MTypeId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool xiugai(MODEL.MemberType mt)
        {
            
            string sql = "update MemberType set MTittle='"+mt.MTittle+"',MDiscount="+mt.MDiscount+" where MTypeId="+mt.MTypeId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
    }
}
