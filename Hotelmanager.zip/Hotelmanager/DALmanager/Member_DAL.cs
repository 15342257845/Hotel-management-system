﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
    public class Member_DAL
    {
        public static DataTable sel(MODEL.Member mbr)
        {
            string sql = "select MId'编号',MName'姓名',MPhone'手机号',MMoney'余额',mt1.MTittle'会员类型' from Member m1 inner join MemberType mt1 on m1.MTypeId=mt1.MTypeId";
            return DALmanager.DBHelper.comSelect(sql);
        }
        

        public static DataTable txtchansel(MODEL.Member mbr)
        {
            string sql = "select MId'编号',MName'姓名',MPhone'手机号',MMoney'余额',mt1.MTittle'会员类型' from Member m1 inner join MemberType mt1 on m1.MTypeId=mt1.MTypeId where  MName like'%" + mbr.MName+"%' and MPhone like'%"+mbr.MPhone+"%'";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static bool insert(MODEL.Member mbr)
        {
            string sql = "insert into Member(MName,MPhone,MMoney,MTypeId) values('"+mbr.MName+"',"+mbr.MPhone+","+mbr.MMoney+","+mbr.MTypeId+")";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
        public static bool del(MODEL.Member mbr)
        {
            string sql = "delete  from Member where MId="+mbr.MId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool update(MODEL.Member mbr)
        {
           string sql= "update Member set MName = '"+mbr.MName+"', MPhone = "+mbr.MPhone+", MMoney = "+mbr.MMoney+", MTypeId = "+mbr.MTypeId+" where MId = "+mbr.MId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static DataTable selsel(MODEL.MemberType mbtr)
        {
            string sql = "select MTypeId from MemberType where MTittle='"+mbtr.MTittle+"'";
            return DALmanager.DBHelper.comSelect(sql);
        }
    }
}
