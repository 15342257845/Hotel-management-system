﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
      public  class Orde_DAL
    {
        public static DataTable tingsel()
        {
            string sql = "select HId,HTittle,HIsdelete from Hall where HIsdelete=0";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable zhuosel(int HID)
        {
            string sql = @"select TTittle,TId from HallTable where HId="+HID+"";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable seldish()
        {
            string sql = " select DId'编号',Dish.DTittle'菜名',DPrice'价格',DChar'首字母',DishType.DTittle'菜品类别' from Dish inner join DishType on DishType.DTypeId=Dish.DTypeId ";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static DataTable zhuoID(MODEL.HallTable htl)
        {
            
            string sql = "select TId from HallTable where TTittle='"+htl.TTittle+"'";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static DataTable selOID(MODEL.Order or)
        {
            string sql = "select OId from [Order] where TId="+or.TId+"";
            return DALmanager.DBHelper.comSelect(sql);
        }
        public static bool insertID(MODEL.OrderDetail odl)
        {
            string sql = "insert into OrderDetail(OId,DishId,ODCount) values("+odl.OId+","+odl.DishId+",1)";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static DataTable  selfill(MODEL.OrderDetail odl)
        {
            string sql = "select ODId,DTittle,ODCount,DPrice from Dish d1 inner join OrderDetail o1 on d1.DId=o1.DishId where OId="+odl.OId+"";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static bool del(MODEL.OrderDetail odl)
        {
            string sql= "delete  from OrderDetail where ODId="+odl.ODId+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

        public static bool update(MODEL.OrderDetail odl)
        {
            string sql = "update OrderDetail set ODCount="+odl.ODCount+" where OId="+odl.ODId + "";
            return DALmanager.DBHelper.insertUpDel(sql);
        }

    }
}
