﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DALmanager
{
    public class recharge_DAL
    {

        public static DataTable sel(int ID)
        {
            string sql = "select MId'编号',MName'姓名',MMoney'余额' from Member where MId="+ID+"";
            return DALmanager.DBHelper.comSelect(sql);
        }

        public static bool chongzhi(int yue,int ID)
        {
            string sql = "update Member set MMoney=MMoney+"+yue+" where MId="+ID+"";
            return DALmanager.DBHelper.insertUpDel(sql);
        }
    }
}
