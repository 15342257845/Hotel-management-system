﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Dish : Form
    {
        public Dish()
        {
            InitializeComponent();
        }

        public void shuaxin()
        {
            dgvliebiao1.DataSource = BLLmanager.Dish_BLL.sel();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DishType dl = new DishType();
            dl.Show();
        }

        private void dishguanli_Load(object sender, EventArgs e)
        {
            
           
            DataTable dtq = BLLmanager.DishType_BLL.jzsel();
            cmbtype.DataSource = dtq;
            cmbtype.DisplayMember = "DTittle";
            cmbtype.ValueMember = "DTypeId";

            DataTable dt = BLLmanager.DishType_BLL.jzsel();
            cbx3.DataSource = dt;
            cbx3.DisplayMember = "DTittle";
            cbx3.ValueMember = "DTypeId";
            cmbtype.Text = "";
            cbx3.Text = "";
            shuaxin();
        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            MODEL.DishType dtp = new MODEL.DishType();
            ds.DTittle = tbname.Text;
            dtp.DTittle = cmbtype.Text ;

            dgvliebiao1.DataSource= BLLmanager.Dish_BLL.txtchansel(ds,dtp);
            
        }

        private void cmbtype_SelectedValueChanged(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            MODEL.DishType dtp = new MODEL.DishType();
            ds.DTittle = tbname.Text;
            dtp.DTittle = cmbtype.Text;

            dgvliebiao1.DataSource = BLLmanager.Dish_BLL.txtchansel(ds, dtp);
        }

        private void dgvliebiao1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao1.CurrentRow.Cells[0].Value.ToString();
            tbnameup.Text = dgvliebiao1.CurrentRow.Cells[1].Value.ToString();
            tbprice.Text = dgvliebiao1.CurrentRow.Cells[2].Value.ToString();
            tbpinyin.Text = dgvliebiao1.CurrentRow.Cells[3].Value.ToString();
            cbx3.Text= dgvliebiao1.CurrentRow.Cells[4].Value.ToString();
            //string type = dgvliebiao1.CurrentRow.Cells[4].Value.ToString();
            //if (type == "川菜")
            //{
            //    cbx3.Text = "";
            //    cbx3.SelectedText = "川菜";
            //}
            //if (type == "汉菜")
            //{
            //    cbx3.Text = "";
            //    cbx3.SelectedText = "汉菜";
            //}
            //if (type == "冰菜")
            //{
            //    cbx3.Text = "";
            //    cbx3.SelectedText = "冰菜";
            //}
            //if (type == "q菜")
            //{
            //    cbx3.Text = "";
            //    cbx3.SelectedText = "q菜";
            //}


            button3.Text = "修改";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button3.Text = "添加";
            tbID.Text = "";
            tbnameup.Text = "";
            tbpinyin.Text = "";
            tbprice.Text = "";
            cmbtype.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == "添加")
            {
                MODEL.Dish ds = new MODEL.Dish();
                ds.DTittle = tbnameup.Text;
                ds.DPrice =Convert.ToDecimal(tbprice.Text);
                ds.DChar =tbpinyin.Text;
                MODEL.DishType dyp = new MODEL.DishType();
                dyp.DTittle = cbx3.Text;
               DataTable dtselcp= BLLmanager.DishType_BLL.selcaip(dyp);
               ds.DTypeId=Convert.ToInt32(dtselcp.Rows[0]["DTypeId"].ToString());
                
               
                

                bool bl = BLLmanager.Dish_BLL.insert(ds);
                if (bl)
                {
                    MessageBox.Show("添加成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！"); shuaxin();
                }
            }
            if (button3.Text == "修改")
            {
                MODEL.Dish ds = new MODEL.Dish();
                ds.DTittle = tbnameup.Text;
                ds.DPrice = Convert.ToDecimal(tbprice.Text);
                ds.DChar = tbpinyin.Text;

                MODEL.DishType dyp = new MODEL.DishType();
                dyp.DTittle = cbx3.Text;
                DataTable dtselcp = BLLmanager.DishType_BLL.selcaip(dyp);
                ds.DTypeId = Convert.ToInt32(dtselcp.Rows[0]["DTypeId"].ToString());

                ds.DId = Convert.ToInt32(tbID.Text);
                bool bl = BLLmanager.Dish_BLL.update(ds);
                if (bl)
                {
                    MessageBox.Show("修改成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！"); shuaxin();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            ds.DId = Convert.ToInt32(tbID.Text);
            bool bl = BLLmanager.Dish_BLL.del(ds);
            if (bl)
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！"); shuaxin();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            shuaxin();
            tbname.Text = "";
            cmbtype.Text = "";
        }

        private void dgvliebiao1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
