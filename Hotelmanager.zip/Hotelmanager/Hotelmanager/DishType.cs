﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Hotelmanager
{
    public partial class DishType : Form
    {
        public DishType()
        {
            InitializeComponent();
        }

        private void btnEsc_Click(object sender, EventArgs e)
        {
            tbID.Text = "添加时自定义";
            tbname.Text = "";
            btnAdd.Text = "添加";
        }

        private void dgvliebiao_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao.CurrentRow.Cells[0].Value.ToString();
            tbname.Text = dgvliebiao.CurrentRow.Cells[1].Value.ToString();
            
            btnAdd.Text = "修改";
        }
        public void shuaxin()
        {
           
            dgvliebiao.DataSource = BLLmanager.DishType_BLL.sel();
        }
        private void dishgl_Load(object sender, EventArgs e)
        {
            shuaxin();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (btnAdd.Text == "添加")
            {
                MODEL.DishType dyp = new MODEL.DishType();
                dyp.DTittle = tbname.Text;
                
                bool bl = BLLmanager.DishType_BLL.tianjia(dyp);
                if (bl)
                {
                    MessageBox.Show("添加成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！");
                    shuaxin();
                }
            }
            if (btnAdd.Text == "修改")
            {
                MODEL.DishType dyp = new MODEL.DishType();
                dyp.DTittle = tbname.Text;
                dyp.DTypeId = Convert.ToInt32(tbID.Text);
                bool blb = BLLmanager.DishType_BLL.update(dyp);
                if (blb)
                {
                    MessageBox.Show("修改成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！");
                    shuaxin();
                }
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {

            MODEL.DishType dyp = new MODEL.DishType();

            dyp.DTypeId = Convert.ToInt32(tbID.Text);
            bool blb = BLLmanager.DishType_BLL.del(dyp);
            if (blb)
            {
                MessageBox.Show("删除成功！");
                shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！");
                shuaxin();
            }
        }
    }
}
