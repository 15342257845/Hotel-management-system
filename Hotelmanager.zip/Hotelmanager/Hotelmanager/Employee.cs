﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Hotelmanager
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }
        public void shuaxin()
        {
            dgvliebiao.DataSource = BLLmanager.Employee_BLL.yaungongsel();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void XMB_Load(object sender, EventArgs e)
        {


            shuaxin();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (btnAdd.Text == "添加")
            {
                MODEL.Employee emp = new MODEL.Employee();
                emp.EName = tbuser.Text;
                emp.EPwd = tbpass.Text;

                if (rbtjingli.Checked)
                {
                    emp.EType = true;
                }
                if (rbtdianyuan.Checked)
                {
                    emp.EType = false;
                }
                bool bl = BLLmanager.Employee_BLL.tianjia(emp);
                if (bl)
                {
                    MessageBox.Show("添加成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！");
                    shuaxin();
                }

            }
            if (btnAdd.Text == "修改")
            {
                MODEL.Employee emp = new MODEL.Employee();
                emp.EId = Convert.ToInt32(tbID.Text);
                emp.EName = tbuser.Text;
                emp.EPwd = tbpass.Text;

                if (rbtjingli.Checked)
                {
                    emp.EType = false;
                }
                if (rbtdianyuan.Checked)
                {
                    emp.EType = true;

                }

                bool bl = BLLmanager.Employee_BLL.xiugai(emp);
                if (bl)
                {
                    MessageBox.Show("修改成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！");
                    shuaxin();
                }

            }
          }

        private void btnEsc_Click(object sender, EventArgs e)
        {
            tbuser.Text = "";
             tbpass.Text="";
            tbID.Text = "添加时自定义";
            btnAdd.Text = "添加";
        }

        private void dgvliebiao_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
            
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
           int id=Convert.ToInt32(dgvliebiao.CurrentRow.Cells[0].Value.ToString());
            MODEL.Employee emp = new MODEL.Employee();
            emp.EId = id;
            bool bl = BLLmanager.Employee_BLL.shanchu(emp);
            if (bl)
            {
                MessageBox.Show("删除成功！");
                shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！");
                shuaxin();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void 会员管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MemberType hl = new MemberType();
            hl.Show();
        }

        private void dgvliebiao_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void dgvliebiao_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvliebiao_CellMouseDoubleClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao.CurrentRow.Cells[0].Value.ToString();
            tbuser.Text = dgvliebiao.CurrentRow.Cells[1].Value.ToString();
            tbpass.Text = dgvliebiao.CurrentRow.Cells[2].Value.ToString();
            string type = dgvliebiao.CurrentRow.Cells[3].Value.ToString();
            if (type == "经理")
            {
                rbtjingli.Checked = true;

            }
            if (type == "员工")
            {
                rbtdianyuan.Checked = true;
            }
            btnAdd.Text = "修改";
        }
    }
}
