﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Hall : Form
    {
        public Hall()
        {
            InitializeComponent();
        }
        public void shuaxin()
        {
            dgvliebiao.DataSource = BLLmanager.Hall_BLL.sel();
        }
        private void tingbao_Load(object sender, EventArgs e)
        {
            shuaxin();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (btnAdd.Text == "添加")
            {
                MODEL.Hall hl = new MODEL.Hall();
                hl.HTittle = tbname.Text;

                bool bl = BLLmanager.Hall_BLL.insert(hl);
                if (bl)
                {
                    MessageBox.Show("添加成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！");
                    shuaxin();
                }
            }
            if (btnAdd.Text == "修改")
            {
                MODEL.Hall hl = new MODEL.Hall();
                hl.HId =Convert.ToInt32(tbID.Text);
                hl.HTittle = tbname.Text;
             
                bool blb = BLLmanager.Hall_BLL.update(hl);
                if (blb)
                {
                    MessageBox.Show("修改成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！");
                    shuaxin();
                }
            }

        }

        private void dgvliebiao_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao.CurrentRow.Cells[0].Value.ToString();
            tbname.Text = dgvliebiao.CurrentRow.Cells[1].Value.ToString();

            btnAdd.Text = "修改";
        }

        private void btnEsc_Click(object sender, EventArgs e)
        {
            tbID.Text = "添加时自定义";
            tbname.Text = "";
            btnAdd.Text = "添加";
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            MODEL.Hall hl = new MODEL.Hall();

            hl.HId = Convert.ToInt32(tbID.Text);
            bool blb = BLLmanager.Hall_BLL.del(hl);
            if (blb)
            {
                MessageBox.Show("删除成功！");
                shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！");
                shuaxin();
            }
            
        }
    }
}
