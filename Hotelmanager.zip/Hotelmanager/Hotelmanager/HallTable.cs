﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class HallTable : Form
    {
        public HallTable()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hall hl = new Hall();
            hl.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void shuaxin()
        {
            dgvliebiao1.DataSource = BLLmanager.HallTable_BLL.sel();
        }
        private void HallTable_Load(object sender, EventArgs e)
        {
            shuaxin();
            comboBox1.DataSource = BLLmanager.Hall_BLL.jzsel();
            comboBox1.DisplayMember = "HId";
           // comboBox1.ValueMember = "DTypeId";
        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {

            MODEL.HallTable htl = new MODEL.HallTable();
            //htl.TTittle=
            //cmbtype.DataSource = BLLmanager.HallTable_BLL.jzsel();

            //cmbtype.DisplayMember = "DTittle";
            //cmbtype.ValueMember = "DTypeId";
            //dgvliebiao1.DataSource = BLLmanager.Member_BLL.txtchansel(htl);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            shuaxin();
            tbname.Text = "";
            cmbtype.Text = "";
        }

        

        private void tbname_TextChanged_1(object sender, EventArgs e)
        {

            MODEL.HallTable htl = new MODEL.HallTable();
            //if (!string.IsNullOrEmpty(tbname.Text))
            //{
            htl.HId = String.IsNullOrEmpty(tbname.Text) ? -1 : Convert.ToInt32(tbname.Text);


            if (cmbtype.Text == "空闲")
            {
                htl.TIsFree = 0;
            }
            if (cmbtype.Text == "非空闲")
            {
                htl.TIsFree = 1;
            }
            dgvliebiao1.DataSource = BLLmanager.HallTable_BLL.likesel(htl);

            //}
            //else
            //{
            //    return;
            //}

        }

        private void cmbtype_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbtype_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void cmbtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            MODEL.HallTable htl = new MODEL.HallTable();
            //if (!string.IsNullOrEmpty(tbname.Text))
            //{
            htl.HId = String.IsNullOrEmpty(tbname.Text) ? 0 : Convert.ToInt32(tbname.Text);


            if (cmbtype.Text == "空闲")
            {
                htl.TIsFree = 0;
            }
            if (cmbtype.Text == "非空闲")
            {
                htl.TIsFree = 1;
            }
            dgvliebiao1.DataSource = BLLmanager.HallTable_BLL.likesel(htl);

            //}
            //else
            //{
            //    return;
            //}
        }

        private void tbname_Leave(object sender, EventArgs e)
        {
            //shuaxin();
        }

        private void dgvliebiao1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao1.CurrentRow.Cells[0].Value.ToString();
            tbnameup.Text = dgvliebiao1.CurrentRow.Cells[1].Value.ToString();
            comboBox1.Text = dgvliebiao1.CurrentRow.Cells[3].Value.ToString();
            string iffree = dgvliebiao1.CurrentRow.Cells[2].Value.ToString();
            if (iffree == "非空闲")
            {
                radioButton2.Select();

            }
            if (iffree == "空闲")
            {
                radioButton1.Select();

            }
            //comboBox1.DataSource = BLLmanager.Hall_BLL.seljz();

            //comboBox1.DisplayMember = "HTittle";
            //comboBox1.ValueMember = "HId";
            button3.Text = "修改";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == "添加")
            {
                MODEL.HallTable htl = new MODEL.HallTable();
                htl.TTittle = tbnameup.Text;
                htl.HId = Convert.ToInt32(comboBox1.Text);
                if (radioButton1.Checked)
                {
                    htl.TIsFree = 0;

                }
                if (radioButton2.Checked)
                {
                    htl.TIsFree = 1;
                }




                bool bl = BLLmanager.HallTable_BLL.insert(htl);
                if (bl)
                {
                    
                    MessageBox.Show("添加成功！"); shuaxin();
                   
                        BLLmanager.HallTable_BLL.insertqqq();
                    
                    
                    
                }
                else
                {
                    MessageBox.Show("添加失败！"); shuaxin();
                }



            }
            if (button3.Text == "修改")
            {
                MODEL.HallTable htl = new MODEL.HallTable();
                htl.TTittle = tbnameup.Text;

                htl.HId = Convert.ToInt32(comboBox1.Text);
                if (radioButton1.Checked)
                {
                    htl.TIsFree = 0;
                }

                if (radioButton2.Checked)
                {
                    htl.TIsFree = 1;
                }



                htl.TId = Convert.ToInt32(tbID.Text);
                bool bl = BLLmanager.HallTable_BLL.update(htl);
                if (bl)
                {
                    MessageBox.Show("修改成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！"); shuaxin();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button3.Text = "添加";
            tbID.Text = "添加时自定义编号";
            tbnameup.Text = "";
            comboBox1.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MODEL.HallTable htl = new MODEL.HallTable();

            htl.TId = Convert.ToInt32(tbID.Text);
            bool bl = BLLmanager.HallTable_BLL.del(htl);
            if (bl)
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
            else
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
        }
    }
}
