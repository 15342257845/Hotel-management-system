﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        
        private void btnlogin_Click(object sender, EventArgs e)
        {
            MODEL.Employee emp = new MODEL.Employee();
            emp.EName = tbxuser.Text;
            emp.EPwd = tbxpass.Text;
            DataTable dtsel = BLLmanager.Employee_BLL.Loginsel(emp);
            if (dtsel.Rows.Count > 0)
            {
                MessageBox.Show("登陆成功！");
                bool bltype = Convert.ToBoolean(dtsel.Rows[0]["EType"].ToString());

                Main zym = new Main(bltype);
                zym.Show();
                
            }
            else
            {
                MessageBox.Show("登陆失败！");
            }
        }

        private void cbxstyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxstyle.Text=="风格一")
            {
                skinEngine1.SkinFile = "skin/DeepOrange.ssk";
            }
            if (cbxstyle.Text == "风格二")
            {
                skinEngine1.SkinFile = "skin/MidsummerColor2.ssk";
            }
            if (cbxstyle.Text == "风格三")
            {
                skinEngine1.SkinFile = "skin/Vista2_color1.ssk";
            }
           
        }

        private void Login_Load(object sender, EventArgs e)
        {
            
        }
    }
}
