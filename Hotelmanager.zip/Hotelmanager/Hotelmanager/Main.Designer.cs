﻿namespace Hotelmanager
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.yuangongguanli = new System.Windows.Forms.ToolStripMenuItem();
            this.会员管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜品管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.餐厅管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关闭ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.结算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yuangongguanli,
            this.会员管理ToolStripMenuItem,
            this.菜品管理ToolStripMenuItem,
            this.餐厅管理ToolStripMenuItem,
            this.结算ToolStripMenuItem,
            this.关闭ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(689, 56);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // yuangongguanli
            // 
            this.yuangongguanli.Image = ((System.Drawing.Image)(resources.GetObject("yuangongguanli.Image")));
            this.yuangongguanli.Name = "yuangongguanli";
            this.yuangongguanli.Size = new System.Drawing.Size(116, 52);
            this.yuangongguanli.Text = "员工管理";
            this.yuangongguanli.Click += new System.EventHandler(this.员工管理ToolStripMenuItem_Click);
            // 
            // 会员管理ToolStripMenuItem
            // 
            this.会员管理ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("会员管理ToolStripMenuItem.Image")));
            this.会员管理ToolStripMenuItem.Name = "会员管理ToolStripMenuItem";
            this.会员管理ToolStripMenuItem.Size = new System.Drawing.Size(116, 52);
            this.会员管理ToolStripMenuItem.Text = "会员管理";
            this.会员管理ToolStripMenuItem.Click += new System.EventHandler(this.会员管理ToolStripMenuItem_Click);
            // 
            // 菜品管理ToolStripMenuItem
            // 
            this.菜品管理ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("菜品管理ToolStripMenuItem.Image")));
            this.菜品管理ToolStripMenuItem.Name = "菜品管理ToolStripMenuItem";
            this.菜品管理ToolStripMenuItem.Size = new System.Drawing.Size(116, 52);
            this.菜品管理ToolStripMenuItem.Text = "菜品管理";
            this.菜品管理ToolStripMenuItem.Click += new System.EventHandler(this.菜品管理ToolStripMenuItem_Click);
            // 
            // 餐厅管理ToolStripMenuItem
            // 
            this.餐厅管理ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("餐厅管理ToolStripMenuItem.Image")));
            this.餐厅管理ToolStripMenuItem.Name = "餐厅管理ToolStripMenuItem";
            this.餐厅管理ToolStripMenuItem.Size = new System.Drawing.Size(116, 52);
            this.餐厅管理ToolStripMenuItem.Text = "餐厅管理";
            this.餐厅管理ToolStripMenuItem.Click += new System.EventHandler(this.餐厅管理ToolStripMenuItem_Click);
            // 
            // 关闭ToolStripMenuItem
            // 
            this.关闭ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("关闭ToolStripMenuItem.Image")));
            this.关闭ToolStripMenuItem.Name = "关闭ToolStripMenuItem";
            this.关闭ToolStripMenuItem.Size = new System.Drawing.Size(92, 52);
            this.关闭ToolStripMenuItem.Text = "关闭";
            this.关闭ToolStripMenuItem.Click += new System.EventHandler(this.关闭ToolStripMenuItem_Click);
            // 
            // 结算ToolStripMenuItem
            // 
            this.结算ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("结算ToolStripMenuItem.Image")));
            this.结算ToolStripMenuItem.Name = "结算ToolStripMenuItem";
            this.结算ToolStripMenuItem.Size = new System.Drawing.Size(92, 52);
            this.结算ToolStripMenuItem.Text = "结算";
            this.结算ToolStripMenuItem.Click += new System.EventHandler(this.结算ToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(689, 397);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Main";
            this.Text = "餐饮管理系统";
            this.Load += new System.EventHandler(this.zhuyemian_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem yuangongguanli;
        private System.Windows.Forms.ToolStripMenuItem 会员管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 餐厅管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜品管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关闭ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 结算ToolStripMenuItem;
    }
}