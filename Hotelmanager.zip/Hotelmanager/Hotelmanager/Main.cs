﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        public Main(bool bltype)
        {
            InitializeComponent();
            if (bltype==false)
            {
                yuangongguanli.Enabled = true;
            }
            else
            {
                yuangongguanli.Enabled = false;
            }
        }

        


        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MemberType hygl = new MemberType();
            hygl.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void 菜品ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 员工管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee xb = new Employee();
            xb.Show();
        }

        private void 会员管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Member hl = new Member();
            hl.Show();
        }

        private void 菜品管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dish dl = new Dish();
            dl.Show();
        }

        private void zhuyemian_Load(object sender, EventArgs e)
        {

        }

        private void 餐厅管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HallTable ht = new HallTable();
            ht.Show();
        }

        private void 结算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Order od = new Order();
            od.Show();
        }

        private void 关闭ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
