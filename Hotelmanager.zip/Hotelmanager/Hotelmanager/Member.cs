﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Member : Form
    {
        public Member()
        {
            InitializeComponent();
        }
        public void shuaxin()
        {
            MODEL.Member mbr = new MODEL.Member();
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.sel(mbr);
        }
        private void hygl_Load(object sender, EventArgs e)
        {
            shuaxin();
            DataTable dt = BLLmanager.MemberType_BLL.jzsel();
            cbxtype.DataSource = dt;
            cbxtype.DisplayMember = "MTittle";
            cbxtype.ValueMember = "MTypeId";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            shuaxin();
            tbname.Text = "";
            tbtel.Text = "";
        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MName = tbname.Text;
            mbr.MPhone = tbtel.Text;
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.txtchansel(mbr);
        }

        private void tbtel_TextChanged(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MName = tbname.Text;
            mbr.MPhone = tbtel.Text;
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.txtchansel(mbr);
        }

        private void dgvliebiao1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao1.CurrentRow.Cells[0].Value.ToString();
            tbnameup.Text = dgvliebiao1.CurrentRow.Cells[1].Value.ToString();
            tbtelup.Text = dgvliebiao1.CurrentRow.Cells[2].Value.ToString();
            tbyue.Text = dgvliebiao1.CurrentRow.Cells[3].Value.ToString();
            cbxtype.Text = dgvliebiao1.CurrentRow.Cells[4].Value.ToString();

            
           

            button3.Text = "修改";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MemberType hygl = new MemberType();
            hygl.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tbID.Text = "";
            tbnameup.Text = "";
            tbtelup.Text = "";
            tbyue.Text = "";
            cbxtype.Text = "";
            button3.Text = "添加";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text=="添加")
            {
                MODEL.Member mbr = new MODEL.Member();
                mbr.MName = tbnameup.Text;
                mbr.MPhone = tbtelup.Text;
                mbr.MMoney = Convert.ToDecimal(tbyue.Text);
                MODEL.MemberType mbtr = new MODEL.MemberType();
                string Mtitle = cbxtype.Text;
                
                mbtr.MTittle = Mtitle;
                DataTable dt= BLLmanager.Member_BLL.selsel(mbtr);

                mbr.MTypeId = Convert.ToInt32(dt.Rows[0]["MTypeId"].ToString());
                
                //mbr.MTypeId = 1;


                bool bl = BLLmanager.Member_BLL.insert(mbr);
                if (bl)
                {
                    MessageBox.Show("添加成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！"); shuaxin();
                }
            }
            if (button3.Text == "修改")
            {
                MODEL.Member mbr = new MODEL.Member();
                mbr.MName = tbnameup.Text;
                mbr.MPhone = tbtelup.Text;
                mbr.MMoney = Convert.ToDecimal(tbyue.Text);

                MODEL.MemberType mbtr = new MODEL.MemberType();
                string Mtitle = cbxtype.Text;

                mbtr.MTittle = Mtitle;
                DataTable dt = BLLmanager.Member_BLL.selsel(mbtr);

                mbr.MTypeId = Convert.ToInt32(dt.Rows[0]["MTypeId"].ToString());


                mbr.MId =Convert.ToInt32(tbID.Text);
                bool bl = BLLmanager.Member_BLL.update(mbr);
                if (bl)
                {
                    MessageBox.Show("修改成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！"); shuaxin();
                }
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MId =Convert.ToInt32(tbID.Text);
            bool bl = BLLmanager.Member_BLL.del(mbr);
            if (bl)
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
             else 
            {
                MessageBox.Show("删除失败！"); shuaxin();
            }
        }
    }
}
