﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class MemberType : Form
    {
        public MemberType()
        {
            InitializeComponent();
        }

        public void shuaxin()
        {
          dgvhygl.DataSource = BLLmanager.MemberType_BLL.sel();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MODEL.MemberType mt = new MODEL.MemberType();
            mt.MTypeId =Convert.ToInt32( tbhyID.Text);
          bool bl=  BLLmanager.MemberType_BLL.shanchu(mt);
            if (bl)
            {
                MessageBox.Show("删除成功！");
                shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！");
                shuaxin();
            }
        }

        private void huiyuanguanli_Load(object sender, EventArgs e)
        {
            shuaxin();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "添加")
            {
                MODEL.MemberType mt = new MODEL.MemberType();
                mt.MTittle = tbhytitle.Text;
                mt.MDiscount = Convert.ToDecimal(tbhyzhekou.Text);
                bool bl = BLLmanager.MemberType_BLL.tianjia(mt);
                if (bl)
                {
                    MessageBox.Show("添加成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！");
                    shuaxin();
                }
            }
            if (button1.Text == "修改")
            {
                MODEL.MemberType mt = new MODEL.MemberType();
                mt.MTypeId = Convert.ToInt32(tbhyID.Text);
                mt.MTittle = tbhytitle.Text;
                mt.MDiscount = Convert.ToDecimal(tbhyzhekou.Text);



                bool bl = BLLmanager.MemberType_BLL.xiugai(mt);
                if (bl)
                {
                    MessageBox.Show("修改成功！");
                    shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！");
                    shuaxin();
                }
            }
           
        }

        private void dgvhygl_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbhyID.Text = dgvhygl.CurrentRow.Cells[0].Value.ToString();
            tbhytitle.Text = dgvhygl.CurrentRow.Cells[1].Value.ToString();
            tbhyzhekou.Text = dgvhygl.CurrentRow.Cells[2].Value.ToString();
            button1.Text = "修改";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            tbhyID.Text = "添加时编号自定义";
            tbhytitle.Text = "";
            tbhyzhekou.Text = "";
            button1.Text = "添加";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }
    }
}
