﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class Order : Form
    {
        public Order()
        {
            InitializeComponent();
        }

        private void Order_Load(object sender, EventArgs e)
        {
            cbxting.DataSource = BLLmanager.Order_BLL.tingsel();
            cbxting.DisplayMember = "HTittle";
            cbxting.ValueMember = "HId";
            dgv1.DataSource = BLLmanager.Order_BLL.seldish();

            jisuan();
        }

        private void cbxzhuo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 1.查询餐桌编号
            MODEL.HallTable htl = new MODEL.HallTable();
            htl.TTittle = cbxzhuo.Text;
            DataTable dt = BLLmanager.Order_BLL.zhuoID(htl);
            int TId = Convert.ToInt32(dt.Rows[0]["TId"].ToString());

           // 2.通过桌子ID查询订单编号ID
            MODEL.Order or = new MODEL.Order();
            or.TId = TId;
            DataTable dto = BLLmanager.Order_BLL.selOID(or);
            int OId = Convert.ToInt32(dto.Rows[0]["OId"].ToString());

            //3.通过订单编号ID查到的数据传给表2
            MODEL.OrderDetail odl = new MODEL.OrderDetail();
            odl.OId = OId;
            dgv2.DataSource = BLLmanager.Order_BLL.selfill(odl);


        }

        private void cbxting_TextChanged(object sender, EventArgs e)
        {
            MODEL.Hall hl = new MODEL.Hall();
            int HID = 0;
            // hl.HId =a;

            bool bl = int.TryParse(cbxting.SelectedValue.ToString(), out HID);
            if (bl)
            {
                // hl.HId = int.Parse(cbxting.SelectedValue.ToString());
                cbxzhuo.DataSource = BLLmanager.Order_BLL.zhuosel(HID);

                cbxzhuo.DisplayMember = "TTittle";
                cbxzhuo.ValueMember = "TId";
            }
        }

        private void dgv1_DoubleClick(object sender, EventArgs e)
        {
           // 1.查询菜种编号
            int dishID = Convert.ToInt32(dgv1.CurrentRow.Cells["编号"].Value.ToString());
        
          //  2.查询桌子ID
            MODEL.HallTable htl = new MODEL.HallTable();
            htl.TTittle=cbxzhuo.Text;          
            DataTable  dt =  BLLmanager.Order_BLL.zhuoID(htl);
            int TId =Convert.ToInt32(dt.Rows[0]["TId"].ToString());
            MODEL.Order or = new MODEL.Order();
            or.TId = TId;
           DataTable dto= BLLmanager.Order_BLL.selOID(or);
            int OId = Convert.ToInt32(dto.Rows[0]["OId"].ToString());

            //3.插入到详情表
            MODEL.OrderDetail odl = new MODEL.OrderDetail();
            odl.OId = OId;
            odl.DishId = dishID;
              BLLmanager.Order_BLL.insertID(odl);

            //4.查询表信息
            odl.OId = OId;
            dgv2.DataSource = BLLmanager.Order_BLL.selfill(odl);
            jisuan();
        }
        public void shuaxin()
        {
            //MODEL.HallTable htl = new MODEL.HallTable();
            ////htl.TTittle = cbxzhuo.Text;

            //DataTable dt = BLLmanager.Order_BLL.zhuoID(htl);
            //int TId = Convert.ToInt32(dt.Rows[0]["TId"].ToString());

           int TId=int.Parse( cbxzhuo.SelectedValue.ToString());

            MODEL.Order or = new MODEL.Order();
            or.TId = TId;
            DataTable dto = BLLmanager.Order_BLL.selOID(or);
            int OId = Convert.ToInt32(dto.Rows[0]["OId"].ToString());
            MODEL.OrderDetail odl = new MODEL.OrderDetail();
            
            odl.OId = OId;
            dgv2.DataSource = BLLmanager.Order_BLL.selfill(odl);
        }

        private void cbxzhuo_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void cbxting_SelectedIndexChanged(object sender, EventArgs e)
        {
           
           
        }

        private void dgv1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv2.RowCount < 1)
            {
                MessageBox.Show("没有可以删除的！");
            }
            else
            {
              int ODId= Convert.ToInt32(dgv2.CurrentRow.Cells[0].Value.ToString());
                MODEL.OrderDetail odl = new MODEL.OrderDetail();
                odl.ODId = ODId;
              bool bl=  BLLmanager.Order_BLL.del(odl);
                if (bl)
                {
                    MessageBox.Show("删除成功！");
                    shuaxin();
                    jisuan();
                }
                else
                {
                    MessageBox.Show("删除失败！");
                    shuaxin();
                    jisuan();
                }
            }
        }

        private void dgv2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int count = Convert.ToInt32(dgv2.CurrentRow.Cells[2].Value.ToString());
            int ODId = Convert.ToInt32(dgv2.CurrentRow.Cells[0].Value.ToString());
            MODEL.OrderDetail odl = new MODEL.OrderDetail();
            BLLmanager.Order_BLL.update(odl);
            jisuan();
        }

        public void jisuan()
        {
            decimal total = 0;
            var rows = dgv2.Rows;
            for (int i = 0; i < rows.Count; i++)
            {
                int count = int.Parse(rows[i].Cells[2].Value.ToString());
                decimal price = Convert.ToDecimal(rows[i].Cells[3].Value.ToString());
                total += count * price;
            }
            label4.Text = total.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OrderDetail od = new OrderDetail();
            od.Show();
        }
    }
}
