﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class dishguanli : Form
    {
        public dishguanli()
        {
            InitializeComponent();
        }

        public void shuaxin()
        {
            dgvliebiao1.DataSource = BLLmanager.Dish_BLL.sel();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dishgl dl = new dishgl();
            dl.Show();
        }

        private void dishguanli_Load(object sender, EventArgs e)
        {
            
            shuaxin();
            //DataTable dt = BLLmanager.DishType_BLL.sel();
            //comboBox1.DataSource = dt;
            //comboBox1.DisplayMember = "DTittle";
            //comboBox1.ValueMember = "DTypeId";
        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            ds.DTittle = tbname.Text;
            
            if (cmbtype.Text=="川菜")
            {
                ds.DTypeId = 101;
            }
            if (cmbtype.Text == "汉菜")
            {
                ds.DTypeId = 102;
            }
            if (cmbtype.Text == "冰菜")
            {
                ds.DTypeId = 103;
            }
            if (cmbtype.Text == "q菜")
            {
                ds.DTypeId = 104;
            }

           dgvliebiao1.DataSource= BLLmanager.Dish_BLL.txtchansel(ds);
            
        }

        private void cmbtype_SelectedValueChanged(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            ds.DTittle = tbname.Text;

            if (cmbtype.Text == "川菜")
            {
                ds.DTypeId = 101;
            }
            if (cmbtype.Text == "汉菜")
            {
                ds.DTypeId = 102;
            }
            if (cmbtype.Text == "冰菜")
            {
                ds.DTypeId = 103;
            }
            if (cmbtype.Text == "q菜")
            {
                ds.DTypeId = 104;
            }

            dgvliebiao1.DataSource = BLLmanager.Dish_BLL.txtchansel(ds);
        }

        private void dgvliebiao1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao1.CurrentRow.Cells[0].Value.ToString();
            tbnameup.Text = dgvliebiao1.CurrentRow.Cells[1].Value.ToString();
            tbprice.Text = dgvliebiao1.CurrentRow.Cells[2].Value.ToString();
            tbpinyin.Text = dgvliebiao1.CurrentRow.Cells[3].Value.ToString();
            string type = dgvliebiao1.CurrentRow.Cells[4].Value.ToString();
            if (type == "川菜")
            {
                comboBox1.Text = "";
                comboBox1.SelectedText = "川菜";
            }
            if (type == "汉菜")
            {
                comboBox1.Text = "";
                comboBox1.SelectedText = "汉菜";
            }
            if (type == "冰菜")
            {
                comboBox1.Text = "";
                comboBox1.SelectedText = "冰菜";
            }
            if (type == "q菜")
            {
                comboBox1.Text = "";
                comboBox1.SelectedText = "q菜";
            }
           

            button3.Text = "修改";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button3.Text = "添加";
            tbnameup.Text = "";
            tbpinyin.Text = "";
            tbprice.Text = "";
            cmbtype.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == "添加")
            {
                MODEL.Dish ds = new MODEL.Dish();
                ds.DTittle = tbnameup.Text;
                ds.DPrice =Convert.ToDecimal(tbprice.Text);
                ds.DChar =tbpinyin.Text;

                if (comboBox1.Text == "川菜")
                {
                    ds.DTypeId= 101;
                }
                if (comboBox1.Text == "汉菜")
                {
                    ds.DTypeId = 102;
                }
                if (comboBox1.Text == "冰菜")
                {
                    ds.DTypeId = 103;
                }
                if (comboBox1.Text == "q菜")
                {
                    ds.DTypeId = 104;
                }
                

                bool bl = BLLmanager.Dish_BLL.insert(ds);
                if (bl)
                {
                    MessageBox.Show("添加成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！"); shuaxin();
                }
            }
            if (button3.Text == "修改")
            {
                MODEL.Dish ds = new MODEL.Dish();
                ds.DTittle = tbnameup.Text;
                ds.DPrice = Convert.ToDecimal(tbprice.Text);
                ds.DChar = tbpinyin.Text;

                if (comboBox1.Text == "川菜")
                {
                    ds.DTypeId = 101;
                }
                if (comboBox1.Text == "汉菜")
                {
                    ds.DTypeId = 102;
                }
                if (comboBox1.Text == "冰菜")
                {
                    ds.DTypeId = 103;
                }
                if (comboBox1.Text == "q菜")
                {
                    ds.DTypeId = 104;
                }
                ds.DId = Convert.ToInt32(tbID.Text);
                bool bl = BLLmanager.Dish_BLL.update(ds);
                if (bl)
                {
                    MessageBox.Show("修改成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！"); shuaxin();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MODEL.Dish ds = new MODEL.Dish();
            ds.DId = Convert.ToInt32(tbID.Text);
            bool bl = BLLmanager.Dish_BLL.del(ds);
            if (bl)
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
            else
            {
                MessageBox.Show("删除失败！"); shuaxin();
            }
        }
    }
}
