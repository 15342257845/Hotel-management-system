﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class hygl : Form
    {
        public hygl()
        {
            InitializeComponent();
        }
        public void shuaxin()
        {
            MODEL.Member mbr = new MODEL.Member();
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.sel(mbr);
        }
        private void hygl_Load(object sender, EventArgs e)
        {
            shuaxin();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            shuaxin();
        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MName = tbname.Text;
            mbr.MPhone = tbtel.Text;
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.txtchansel(mbr);
        }

        private void tbtel_TextChanged(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MName = tbname.Text;
            mbr.MPhone = tbtel.Text;
            dgvliebiao1.DataSource = BLLmanager.Member_BLL.txtchansel(mbr);
        }

        private void dgvliebiao1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tbID.Text = dgvliebiao1.CurrentRow.Cells[0].Value.ToString();
            tbnameup.Text = dgvliebiao1.CurrentRow.Cells[1].Value.ToString();
            tbtelup.Text = dgvliebiao1.CurrentRow.Cells[2].Value.ToString();
            tbyue.Text = dgvliebiao1.CurrentRow.Cells[3].Value.ToString();
            string type = dgvliebiao1.CurrentRow.Cells[4].Value.ToString();
            if (type=="钻石")
            {
                cbxtype.Text = "";
                cbxtype.SelectedText = "钻石";
            }
            if (type == "铂金")
            {
                cbxtype.Text = "";
                cbxtype.SelectedText = "铂金";
            }
            if (type == "黄金")
            {
                cbxtype.Text = "";
                cbxtype.SelectedText = "黄金";
            }
            if (type == "白银")
            {
                cbxtype.Text = "";
                cbxtype.SelectedText = "白银";
            }
            if (type == "青铜")
            {
                cbxtype.Text = "";
                cbxtype.SelectedText = "青铜";
            }

            button4.Text = "修改";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            huiyuanguanli hygl = new huiyuanguanli();
            hygl.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tbID.Text = "";
            tbnameup.Text = "";
            tbtelup.Text = "";
            tbyue.Text = "";
            cbxtype.Text = "";
            button3.Text = "添加";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text=="添加")
            {
                MODEL.Member mbr = new MODEL.Member();
                mbr.MName = tbnameup.Text;
                mbr.MPhone = tbtelup.Text;
                mbr.MMoney = Convert.ToDecimal(tbyue.Text);

                if (cbxtype.Text == "钻石")
                {
                    mbr.MTypeId = 1;
                }
                if (cbxtype.Text == "铂金")
                {
                    mbr.MTypeId = 2;
                }
                if (cbxtype.Text == "黄金")
                {
                    mbr.MTypeId = 3;
                }
                if (cbxtype.Text == "白银")
                {
                    mbr.MTypeId = 4;
                }
                if (cbxtype.Text == "青铜")
                {
                    mbr.MTypeId = 5;
                }

                bool bl = BLLmanager.Member_BLL.insert(mbr);
                if (bl)
                {
                    MessageBox.Show("添加成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("添加失败！"); shuaxin();
                }
            }
            if (button3.Text == "修改")
            {
                MODEL.Member mbr = new MODEL.Member();
                mbr.MName = tbnameup.Text;
                mbr.MPhone = tbtelup.Text;
                mbr.MMoney = Convert.ToDecimal(tbyue.Text);
                
                if (cbxtype.Text == "钻石")
                {
                    mbr.MTypeId = 1;
                }
                if (cbxtype.Text == "铂金")
                {
                    mbr.MTypeId = 2;
                }
                if (cbxtype.Text == "黄金")
                {
                    mbr.MTypeId = 3;
                }
                if (cbxtype.Text == "白银")
                {
                    mbr.MTypeId =4;
                }
                if (cbxtype.Text == "青铜")
                {
                    mbr.MTypeId = 5;
                }
                mbr.MId =Convert.ToInt32(tbID.Text);
                bool bl = BLLmanager.Member_BLL.update(mbr);
                if (bl)
                {
                    MessageBox.Show("修改成功！"); shuaxin();
                }
                else
                {
                    MessageBox.Show("修改失败！"); shuaxin();
                }
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MODEL.Member mbr = new MODEL.Member();
            mbr.MId =Convert.ToInt32(tbID.Text);
            bool bl = BLLmanager.Member_BLL.del(mbr);
            if (bl)
            {
                MessageBox.Show("删除成功！"); shuaxin();
            }
             else 
            {
                MessageBox.Show("删除失败！"); shuaxin();
            }
        }
    }
}
