﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotelmanager
{
    public partial class recharge : Form
    {
        public recharge()
        {
            InitializeComponent();
        }

        public void shuaxin()
        {
            int id = Convert.ToInt32(textBox1.Text);
            DataTable dt = BLLmanager.recharge_BLL.sel(id);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int id=Convert.ToInt32(textBox1.Text);
           DataTable dt= BLLmanager.recharge_BLL.sel(id);
            dataGridView1.DataSource = dt;
        }

        private void ye_Click(object sender, EventArgs e)
        {
          
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ye.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          int yue=Convert.ToInt32( textBox2.Text);
           int ID =Convert.ToInt32( dataGridView1.CurrentRow.Cells[0].Value.ToString());
            bool bl = BLLmanager.recharge_BLL.chongzhi(yue,ID);
            if (bl)
            {
                MessageBox.Show("充值成功!");
                shuaxin();
            }
            else
            {
                MessageBox.Show("充值失败!");
                shuaxin();
            }
        }
    }
}
