﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Dish
    {
        public int DId { get; set; }
        public string DTittle { get; set; }
        public Decimal DPrice { get; set; }
        public string DChar { get; set; }

        public int DTypeId { get; set; }

        

   
    }
}
