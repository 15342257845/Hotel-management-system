﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class DishType
    {
        public int DTypeId { get; set; }
        public string DTittle { get; set; }
        

    }
}
