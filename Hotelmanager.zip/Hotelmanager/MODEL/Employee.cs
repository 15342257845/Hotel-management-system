﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Employee
    {
        //EName,EPwd,EType
        public int EId { get; set; }
        public string EName { get; set; }
        public string EPwd { get; set; }
        public bool EType { get; set; }

        public int MyProperty { get; set; }
    }
}
