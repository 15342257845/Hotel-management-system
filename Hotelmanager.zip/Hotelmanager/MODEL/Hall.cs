﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
   public class Hall
    {
        public int HId { get; set; }
        public String HTittle { get; set; }
        public decimal HIsdelete { get; set; }

        
    }
}
