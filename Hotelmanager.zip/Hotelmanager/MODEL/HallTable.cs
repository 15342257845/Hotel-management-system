﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
  public  class HallTable
    {
        public int TId { get; set; }
        public string TTittle { get; set; }
        public int HId { get; set; }
        public int TIsFree { get; set; }
        public decimal TIsdelete { get; set; }
        
    }
}
