﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
   public class MemberType
    {
        public int MTypeId { get; set; }
        public string MTittle { get; set; }
        public decimal MDiscount { get; set; }
      
    }
}
