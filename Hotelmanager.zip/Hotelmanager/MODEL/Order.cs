﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Order
    {
    
            public int OId { get; set; }
        public string ODate { get; set; }
        public int OMoney { get; set; }
        public int OIsPay { get; set; }
        public int TId { get; set; }
        public Decimal ODiscount { get; set; }
    }
}
