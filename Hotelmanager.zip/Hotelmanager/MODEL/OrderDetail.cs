﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class OrderDetail
    {
        public int ODId { get; set; }
        public int OId { get; set; }
        public int DishId { get; set; }
        public int ODCount { get; set; }

        
    }
}
